﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    internal class Book
    {
        //поля
        private string _title;
        private string _author;
        private int _yearOfPublication;
        private int _pagesCount;

        //конструктор
        public Book(string title, string author, int yearOfPublication, int pagesCount)
        {
            _title = title;
            _author = author;
            _yearOfPublication = yearOfPublication;
            _pagesCount = pagesCount;
        }

        //свойства
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }

        public int YearOfPublication
        {
            get { return _yearOfPublication; }
            set { _yearOfPublication = value; }
        }

        public int PagesCount
        {
            get { return _pagesCount; }
            set { _pagesCount = value; }
        }

        //методы
        public void Info()
        {
            Console.WriteLine($"Название книги: {Title}");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Год издания: {YearOfPublication}");
            Console.WriteLine($"Количество страниц: {PagesCount}");
        }

        public void UpdateAuthor(string author)
        {
            Author = author;
        }

        public void CountPages(Book book, Book book1)
        {
            Console.WriteLine($"Общее количество страниц: {PagesCount + book.PagesCount + book1.PagesCount}");
        }

        public void IsOldBook()
        {
            if ((2025 - YearOfPublication) < 50)
            {
                Console.WriteLine("Младше 50 лет");
            }
            else
            {
                Console.WriteLine("Старше 50 лет");
            }
        }

        public void SameAuthor(Book book)
        {
            if (Author == book.Author)
            {
                Console.WriteLine("Авторы совпадают");
            }
            else
            {
                Console.WriteLine("Авторы не совпадают");
            }
        }
    }
}
