﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    public class Human
    {
        //поля
        private string _name; 
        private int _age;
        private char _gender;


        //конструктор
        public Human(string name, int age, char gender)
        {
            _name = name;
            _age = age;
            _gender = gender;
        }



        //свойства
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        public char Gender
        {
            get { return _gender;  }
            set { _gender = value; }
        }

        //методы
        public void Introduce()
        {
            Console.Write($"Привет я {Name} мне {Age} я {Gender}");
            Console.WriteLine();
        }

        public void ChangeAge(int age)
        {
            Age = age;
        }

        public void CelebrateBirthday(int age)
        {
            Age = age + 1;
        }

        public void GreetPerson(Human human)
        {
            Console.Write($"{Name}: Привет {human.Name}");
        }

        public void CompareAges(Human human)
        {
            Console.WriteLine($"{Age} {human.Age}");
            if (Age > human.Age)
            {
                Console.WriteLine($"{Name} старше {Age}");
            }
            if (Age < human.Age)
            {
                Console.WriteLine($"{human.Name} старше {human.Age}");
            }
            else
            {
                Console.WriteLine("одинакого");
            }
        }
    }
}
