﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    internal class Student
    {
        //поля
        public string _name;
        public string _group;
        public double _averageGrade;

        //конструктор
        public Student(string name, string group,double averageGrade)
        {
            _name = name;
            _group = group;
            _averageGrade = averageGrade;
        }

        //свойства
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Group
        {
            get { return _group; }
            set { _group = value; }
        }

        public double AverageGrade
        {
            get { return _averageGrade; }
            set { _averageGrade = value; }
        }

        //методы
        public void ShowInfo ()
        {
            Console.WriteLine($"Имя: {Name}");
            Console.WriteLine($"Группа: {Group}");
            Console.WriteLine($"Средний балл: {AverageGrade}");
        }

        public void ChangeGroup(string newGroup)
        {
            Group = newGroup;
        }

        public void ImproveGrade(double ball)
        {
            AverageGrade += ball;
        }

        public void CompareGrades(Student student)
        {
            if (AverageGrade == student.AverageGrade)
            {
                Console.WriteLine("Средние баллы студентов равны");
            }
            if (AverageGrade > student.AverageGrade)
            {
                Console.WriteLine($"{Name} бал выше чем у {student.Name}");
            }
            else
            {
                Console.WriteLine($"{Name} бал меньше чем у {student.Name}");
            }
        }

        public void Graduate()
        {
            if (AverageGrade >= 3)
            {
                Console.WriteLine("Студент успешно окончил обучение");
            }
            else
            {
                Console.WriteLine("Студент не окончил обучение");
            }

        }
    }
}
