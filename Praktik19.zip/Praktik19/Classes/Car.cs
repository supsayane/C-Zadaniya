﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    internal class Car
    {
        //поля
        private string _brand;
        private string _model;
        private int _year;
        private string _color;


        //конструктор
        public Car(string brand, string model, int year, string color)
        {
            _brand = brand;
            _model = model;
            _year = year;
            _color = color;
        }

        //свойства
        public string Brand
        {
            get { return _brand; }
            set { _brand = value; }
        }

        public string Model
        {
            get { return _model; }
            set { _model = value; }
        }

        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public string Color
        {
            get { return _color; }
            set { _color = value; }
        }

        //методы
        public void Description()
        {
            Console.WriteLine($"Марка автомобиля: {Brand}");
            Console.WriteLine($"Модель автомобиля: {Model}");
            Console.WriteLine($"Год выпуска автомобиля: {Year}");
            Console.WriteLine($"Цвет автомобиля: {Color}");
        }

        public void RepaintCar(string color)
        {
            Color = color;
        }

        public void CheckYear(int year)
        {
            if ( year < Year )
            {
                Console.WriteLine($"Автомобиль выпущен позже {year}");
            }
            else
            {
                Console.WriteLine($"Автомобиль выпущен раньше {year}");
            }
        }

        public void CompareCars(Car car)
        {
            if ( Year == car.Year)
            {
                Console.WriteLine("Год выпуска одинаковый");
            }
            if ( Year > car.Year)
            {
                Console.WriteLine($"{Brand} {Model} автомобиль выпущен позже {car.Brand} {car.Model}");
            }
            else
            {
                Console.WriteLine($"{Brand} {Model} автомобиль выпущен раньше {car.Brand} {car.Model}");
            }
        }

        public void FindSimilarModel(Car car)
        {
            if (Model == car.Model)
            {
                Console.WriteLine("Модели совпадают");
            }
            else
            {
                Console.WriteLine("Модели не совпадают");
            }
        }
    }
}
