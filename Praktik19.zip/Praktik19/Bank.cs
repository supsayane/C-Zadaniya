﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    internal class Bank
    {
        //поля
        public string _bankName;
        public double _interestRate;
        public int _minCreditAmount;

        //конструктор
        public Bank(string bankName, double interestRate, int minCreditAmount)
        {
            _bankName = bankName;
            _interestRate = interestRate;
            _minCreditAmount = minCreditAmount;
        }

        //свойства
        public string BankName
        {
            get { return _bankName; }
            set { _bankName = value; }
        }

        public double InterestRate
        {
            get { return _interestRate; }
            set { _interestRate = value; }
        }

        public int MinCreditAmount
        {
            get { return _minCreditAmount; }
            set { _minCreditAmount = value; }
        }

        //методы
        public void ApproveLoan(int creditAmount)
        {
            if (creditAmount > MinCreditAmount)
            {
                Console.WriteLine("Кредит одобрен");
            }
            else
            {
                Console.WriteLine("Кредит не одобрен");
            }
        }

        public void ApplyInterest(int creditAmount)
        {
            Console.WriteLine($"Начисленные проценты: {InterestRate * creditAmount / 100}");
        }

        public void RecalculatePayment(double interestRate)
        {
            InterestRate = interestRate;
            Console.WriteLine($"Процентная ставка изменена на {interestRate}");
            ApplyInterest(1000);
        }
    }
}

