﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik19
{
    internal class Program
    {

        static void Main(string[] args)
        {

            /*Задание 1. Необходимо создать класс Human, который описывает человека. 
             * Класс должен иметь следующие поля:
            1) имя (name);
            2) возраст (age);
            3) пол (gender);
            и методы:
            1) Introduce (выводит приветствие и основную информацию о человеке);
            2) ChangeAge (меняет возраст человека на указанное количество лет);
            3) CelebrateBirthday (увеличивает возраст на 1 год);
            4) GreetPerson (приветствует другого человека);
            5) CompareAges (сравнивает возраст с другим человеком и возвращает 
            результат сравнения).
            Конструктор класса должен принимать имя, возраст и пол при создании 
            объекта.*/


            //создаем обьект
            Human vasya = new Human("Vasya", 19, 'M');
            Human egor = new Human("Egor", 19, 'M');
            vasya.Introduce(); 
           
            vasya.ChangeAge(12);
            vasya.Introduce();

            vasya.CelebrateBirthday(12);
            vasya.Introduce();

            vasya.GreetPerson(egor);

            vasya.CompareAges(egor);
            vasya.Introduce();
            egor.Introduce();


            /*Задание 2. Необходимо создать класс Book, который описывает книгу. Класс
             * должен иметь следующие поля:
            1) название (title);
            2) автор (author);
            3) год издания (yearOfPublication);
            4) количество страниц (pagesCount);
            и методы:
            1) Info (выводит всю информацию о книге);
            2) UpdateAuthor (заменяет автора книги);
            3) CountPages (подсчитывает общее количество страниц нескольких книг
            вместе);
            4) IsOldBook (проверяет, является ли книга старше 50 лет);
            5) SameAuthor (проверяет, имеют ли две книги одного автора).
            Конструктор класса должен принимать название, автора, год издания и
            количество страниц при создании объекта.*/

            /*Book strugatcki = new Book("Дураки", "Стругацкие", 1970, 200);
            Book strugatcki1 = new Book("молодчики", "Упарника", 2020, 190);
            Book strugatcki2 = new Book("Не дураки", "Дом", 1970, 210);

            strugatcki.Info();

            strugatcki.UpdateAuthor("Egor");
            strugatcki.Info();

            strugatcki.CountPages(strugatcki1, strugatcki2);

            strugatcki1.IsOldBook();

            strugatcki.SameAuthor(strugatcki2);*/


            /*Задание 3. Необходимо создать класс Car, который описывает автомобиль.
             * Класс должен иметь следующие поля:
            1) марка (brand);
            2) модель (model);
            3) год выпуска (year);
            4) цвет (color);
            и методы:
            1) Description (выводит описание автомобиля);
            2) RepaintCar (меняет цвет автомобиля);
            3) CheckYear (проверяет, выпущен ли автомобиль позже указанного года);
            4) CompareCars (сравнивает автомобили по году выпуска);
            5) FindSimilarModel (ищет автомобили с похожей моделью среди списка
            автомобилей)*/

            /*Car car = new Car("BMW", "X5", 2020, "Black");
            Car car1 = new Car("BMW", "X6", 2022, "Black");

            car.Description();

            car.RepaintCar("White");
            car.Description();

            car.CheckYear(2019);

            car.CompareCars(car1);

            car.FindSimilarModel(car1);*/


            /*Задание 4. Необходимо создать класс Student, который описывает студента.
             * Класс должен иметь следующие поля:
            1) имя (name)
            2) группа (group)
            3) средний балл (averageGrade)
            и методы:
            4) ShowInfo (выводит информацию о студенте);
            5) ChangeGroup: меняет группу студента.
            6) ImproveGrade: улучшает средний балл на заданное значение.
            7) CompareGrades: сравнивает средние баллы двух студентов.
            8) Graduate: переводит студента на следующий курс, если его средний балл
            удовлетворяет условию (например, больше 4).
            Конструктор класса должен принимать имя, группу и средний балл при
            создании объекта.*/

            /*Student student = new Student("Egor", "3522П1ИН3", 4);
            Student student1 = new Student("Vasya", "3522П1ИН3", 4);

            student.ShowInfo();

            student.ChangeGroup("3522П1ИН2");
            student.ShowInfo();

            student.ImproveGrade(0.5);
            student.ShowInfo();

            student.CompareGrades(student1);

            student.Graduate();*/


            /*Задание 5. Необходимо создать класс Bank, который описывает банк. Класс
             * должен иметь следующие поля:
            1) название банка (bankName)
            2) процентная ставка по кредиту (interestRate)
            3) минимальная сумма кредита (minCreditAmount)
            и методы:
            4) CalculateMonthlyPayment (рассчитывает ежемесячный платёж по
            кредиту исходя из суммы кредита и срока кредитования);
            5) ApproveLoan (одобряет кредит, если сумма больше минимальной суммы
            кредита);
            6) ApplyInterest (применяет процентную ставку к сумме кредита);
            7) ExtendTerm (продлевает срок кредитования);
            8) RecalculatePayment (пересчитывает ежемесячные платежи после
            изменения условий кредита).*/


            /*Bank bank = new Bank("Sber", 10, 1000);
            Bank bank1 = new Bank("T", 15, 1000);

            bank.ApproveLoan(5000);

            bank.ApplyInterest(1000);

            bank.RecalculatePayment(15);*/

            Console.ReadKey();
        }
    }
}
