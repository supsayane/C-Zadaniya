﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik7
{
    internal class Program
    {
        static double Faktorial(double NumberOne)
        {
            uint fact = 1;
            double result = 1;
            for (uint i = 2; i <= NumberOne; i++)
            {
                fact *= i;
            }
            return result;
        }

        static double Razbiv(ulong NumberOne)
        {
            double result = 1;
            byte a;
            while(NumberOne > 0)
            {
                a = (byte)(NumberOne % 10);
                Console.Write($"{a} ");
                NumberOne /= 10;
            }
            return result;
        }

        static void Main(string[] args)
        {
            /*Задание 1. Даны числа a и b. Выведите в строку:
            a. квадраты всех целых чисел от 10 до b;
            b. третьи степени всех целых чисел от a до 50;
            c. все целые числа от a до b.*/


            /*Console.WriteLine("Введите a");
            double a = Convert.ToDouble(Console.ReadLine());
            a = Math.Ceiling(a);

            Console.WriteLine("Введите b");
            double b = Convert.ToDouble(Console.ReadLine());
            b = Math.Floor(b);

            //a
            for (int i = 10; i <= b; i++)
            {
                int left = i * i;
                Console.Write($"\t{left}");
            }

            //b
            for (double i = a; i<=50; i++)
            {
                double left = i * i * i;
                Console.Write($"\t{left}");
            }*/


            /*Задание 2. Напечатать таблицу умножения на n (вводится
             * пользователем) следующем виде:
            1 х n = n
            2 х n = 2n
            ...
            9 х n = 9n*/

            /*Console.WriteLine("Введите n");
            int n = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i < 10; i++)
            {
                int nx = i * n;
                Console.WriteLine($"{i}*{n}={nx}");
            }*/


            /*Задание 4. Одна штука некоторого товара стоит 20,4 руб. Напечатать
             * таблицу стоимости 2, 3, ..., 20 штук этого товара.*/

            /*const double sale = 20.4;
            for (int i = 2; i <= 20; i++)
            {
                double sales = i * sale;
                Console.WriteLine($"За {i} штук вы заплатите:{sales}");
            }*/


            /*Задание 5. Напечатать таблицу перевода 1, 2, ... 20 долларов США в
             * рубли по текущему курсу (значение курса вводится с клавиатуры).*/

            /*Console.WriteLine("Введите a");
            double a = Convert.ToDouble(Console.ReadLine());

            for (int i = 1; i <= 20; i++)
            {
                double ia = i * a;
                Console.WriteLine($"За {i}$ вы заплатите:{ia}р");
            }*/


            /*Задание 9. Даны числа a и b. Выведите для отрезка [a,b]:
             * a. сумму целый чисел;
            b. произведение целый чисел;
            c. среднее арифметическое целый чисел.*/

            /*Console.WriteLine("Введите a");
            double a = Convert.ToDouble(Console.ReadLine());
            a = Math.Ceiling(a);

            Console.WriteLine("Введите b");
            double b = Convert.ToDouble(Console.ReadLine());
            b = Math.Floor(b);*/

            //a
            /*double ab = 0;
            for (double i = a; i <= b; i++)
            {
                ab += i;
            }
            Console.WriteLine($"a. {ab}");*/

            //b
            /*double pow = 1;
            for (double i = a; i <= b; i++)
            {
                pow *= i;
            }
            Console.WriteLine($"b. {ab}");*/

            //c
            /*double ab = 0;
            int c = 0;
            for (double i = a; i <= b; i++)
            {
                ab += i;
                c++;
            }
            Console.WriteLine($"c. {ab / c}");*/


            /*Задание 10. Дано натуральное число n. Найти сумму чисел:a,c*/

            //a
            /*Console.WriteLine("Введите n");
            int n = Convert.ToInt32(Console.ReadLine());
            double y = 0;
            double x;
            for (int i = 0; i <= n; i++)
            {
                x = Math.Pow(n + i, 2);
                y += x;
            }
            Console.WriteLine(y);*/

            //c
            /*Console.WriteLine("Введите n");
            int n = Convert.ToInt32(Console.ReadLine());
            double y = 0;
            double x = 0;
            for (double i = 2; i <= n; i++)
            {
                x = i / (i + 1);
                y += x;
            }
            Console.WriteLine(y);*/


            /*Задание 15. Последовательность чисел 𝑎0, 𝑎1, 𝑎2, … образуется по закону
             * 𝑎0 = 1, 𝑎𝑘 = 𝑘𝑎𝑘−1 +1𝑘(𝑘 = 1,2, … ). Дано натуральное число n.
            Вывести на экран элементы последовательности 𝑎1, 𝑎2, … , 𝑎*/

            /*Console.WriteLine("Введите n");
            int n = Convert.ToInt32(Console.ReadLine());
            double a = 1;
            double x = 1;
            for (double i = 1; i <= n; i++)
            {
                a = x;
                x = i * a + (1 / i);
            }
            Console.WriteLine(x);*/


            /*Задание 20. Найти сумму (не использовать стандартный метод возведения в степень)
            a. 2^2 + 2^3 + 2^3 + ⋯ 2^10
            b. −1^2 + 2^2 − 3^2 + ⋯ + 10^2
            */

            //a
            /*int y = 4;
            int xy = 0;

            for (int i = 2; i <= 10; i++)
            {
                xy += y;
                y *= 2;
            }
            Console.WriteLine(xy);*/

            //b
            /*int y = 0;
            int xy = 0;

            for (int i = -1; i <= 10; i++)
            {
                y = i * i;
                if (i % 2 == 0)
                {
                    xy += y;
                }
                else
                {
                    xy -= y;
                }
            }
            Console.WriteLine(xy);*/


            /*Задание 28. Вычислить значение бесконечных сумм. Точность
             * вычислений задается пользователем.  c   d        */
            //c
            /*int n = 100000000;
            double s = 0;
            for (double i = 1; i < n; i++)
            {
                double a = 1 / (i * (i + 1));
                s += a;
            }
            Console.WriteLine(s);*/

            //d


            /*Задание 29. Вычислить функции с помощью разложения в ряд.
             * Проверить полученное значение со значением полученным
            стандартным методом.  a и b
            */

            //a
            /*Console.WriteLine("Введите x");
            //Не берите большое значение, лучше до 1.
            //При больших значениях ряд расходится! Проверяла!
            double x = Convert.ToDouble(Console.ReadLine()); //0.3

            double a = x;
            //Console.WriteLine(a);

            Console.WriteLine("Введите n");
            double n = Convert.ToDouble(Console.ReadLine());//0.001

            double xy = a;
            for (byte i = 2; Math.Abs(a) >= n; i++)
            {
                a *= -(i - 1) * x / i;
                //Console.WriteLine(a);
                xy += a;
            }
            Console.WriteLine(xy);//0.262461
                                  //для проверки правильности
            Console.WriteLine(Math.Log(1 + x));*/


            /*Задание 7. Вывести на экран значения x и функции y = 3x2 − 10 
             * в виде таблицы для каждого значения x. X меняется на интервале от x1 до x2 с
             * шагом h. Значения x1, x2, и h вводятся с клавиатуры.*/

            /*Console.Write("Введите левую границу x1: ");
            double x1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите правую границу x2: ");
            double x2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите шаг h: ");
            double h = Convert.ToDouble(Console.ReadLine());

            for (double i = x1; i < x2; i += h)
            {
                Console.WriteLine($"y({i}) = {Math.Pow((3 * i * i), 2) - 10}");
            }

            Console.WriteLine($"y({x2}) = {Math.Pow((3 * x2 * x2), 2) - 10}");*/


            //Задание 14. Вывести числа в следующем виде

            /*Console.Write("Введите количество строк:");
            int n = Convert.ToInt32(Console.ReadLine());*/

            //a
            /*for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= 5; j++)
                Console.Write("5 ");
                Console.WriteLine();
            }
            Console.WriteLine();*/

            //b
            /*for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                Console.Write("5 ");
                Console.WriteLine();
            }
            Console.WriteLine();*/

            //Вариант 20


            //Задание 1
            /*Вывести на экран: все трехзначные числа, сумма цифр которых нечетная.*/

            /*for (int i = 100; i <= 999; i++)
            {
                int i1 = i / 100;
                int i2 = (i / 10) % 10;
                int i3 = i % 10;
                int sum = i1 + i2 + i3;
                if (sum % 2 != 0)
                {
                    Console.WriteLine(i);
                }
            }*/


            //Задание 2
            /*Вывести на экран информацию в следующем виде:*/

            /*Console.WriteLine("Столбцов:");
            int x = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < x; ++i)
            {

            } */



            //Задание 3
            /*Вывести на экран таблицу значений функции y на промежутке
             * [a,b] с шагом h*/

            /*Console.WriteLine("Введите a");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите b");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите h");
            double h = Convert.ToDouble(Console.ReadLine());

            for (double i = a; i < b; i+=h)
            {
                if (i >= 9)
                {
                    Console.WriteLine(Math.Sqrt(i));
                }
                if (i < 0)
                {
                    Console.WriteLine(Math.Sin(i));
                }
                else
                {
                    Console.WriteLine(0.2 * i + Math.Sqrt(0.1 + i));
                }
            }*/


            // Задание 5
            /*Для заданного пользователем натурального n вычислить значение суммы
            Результат вывести на экран в виде форматированной строки.*/

            /*Console.WriteLine("Введите n");
            int n = Convert.ToInt32(Console.ReadLine());

            double sum = 0;

            for (int i = 1; i <= n; i++)
            {
                sum += (int)Math.Pow(-1, i + 1) * i * i;
            }

            Console.WriteLine(sum);*/


            // Задание 6.
            /*Вычислить значение суммы 
             * если 𝑥 — вещественное число, 𝑛 — натуральное число, задаются пользователем. 
             * Результат вывести на экран в виде форматированной строки.*/

            /*Console.WriteLine("Введите n");
            double n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите x");
            double x = Convert.ToDouble(Console.ReadLine());

            double sum = 1;

            for (int i = 1; i <= n; i++)
            {
                sum *= 1 + ((Math.Pow(x, i)) / (Faktorial(n) * Math.Pow(2, i)));
            }
            Console.WriteLine(sum);*/


            // Задание 7
            /*Вычислить сумму с заданной точностью 𝜀 (задается пользователем):*/

            /*Console.WriteLine("Введите e");
            double e = Convert.ToDouble(Console.ReadLine());

            double sum = 0;
            int i = 2;

            double r = 6.0 / (i * i - 9);
            while (Math.Abs(r) >= e)
            {
                sum += r;
                i++;
                r = 6.0 / (i * i - 9);
            }

            Console.WriteLine(sum);*/


            // Задание 8
            /*Вычислить значение функции 𝐹(𝑥) на отрезке [𝑎, 𝑏] с шагом ℎ =
             * 0,01 и точностью 𝜀 (задается пользователем).
            Результат вывести на экран в виде таблицы.*/

            /*Console.WriteLine("Введите a:");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите b:");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Введите значение e: ");
            double e = Convert.ToDouble(Console.ReadLine());

            double h = 0.01;
            double sum = 1;

            for (double i = a; i <= b; i += h)
            {
                int n = 1;
                if (Math.Abs(sum) >= e)
                {
                    sum += Math.Pow(a, n + 1) / Math.Pow(3, n);
                }
                else
                {
                    Console.ReadKey();
                }
                n++;
                Console.WriteLine($"{i}\t\t{sum}");
            }*/


            // Задание 9
            /*Вывести на экран все числа из отрезка [a, b], в записи которых
             * встречается число С (задается пользователем). Результат вывести на
            экран в виде форматированной строки.*/

            Console.WriteLine("Введите a");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите b");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите C");
            int C = Convert.ToInt32(Console.ReadLine());

            for (int i = a; i <= b; i++)
            {
                if (i % 10 == C)
                {
                    Console.Write($"{i} ");
                }
                if (i / 10 == C)
                {
                    Console.Write($"{i} ");
                }
            }


            Console.ReadKey();

        }
    }
}
