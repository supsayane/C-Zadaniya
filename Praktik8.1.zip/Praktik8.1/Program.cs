﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Praktik9;

namespace Praktik8
{
    internal class Program
    {

        static double GetSqrtSum(int NumerOne)
        {
            double result = Math.Sqrt(NumerOne) + NumerOne;
            return result;
        }

        static double GetSumSqrt(int NumerOne)
        {
            double result = NumerOne + Math.Sqrt(NumerOne);
            return result;
        }
        static double GetSumSin(int NumerOne)
        {
            double result = NumerOne + Math.Sin(NumerOne);
            return result;
        }

        static double GetSinSum(int NumerOne)
        {
            double result = Math.Sin(NumerOne) + NumerOne;
            return result;
        }
        static double GetXSumSqrtYDevideYSumSqrtX(int NumerOne, int NumberTwo)
        {
            double result = (NumerOne + Math.Sqrt(NumberTwo)) / (NumberTwo + Math.Sqrt(NumerOne));
            return result;
        }

        static double GetXSumSinYDevideYSumSinX(int NumerOne, int NumberTwo)
        {
            double result = (NumerOne + Math.Sin(NumberTwo)) / (NumberTwo + Math.Sin(NumerOne));
            return result;
        }
        static double GetMax(int NumerOne, int NumberTwo)
        {
            double result = (NumerOne > NumberTwo) ? (NumerOne) : (NumberTwo);
            return result;
        }
        static double GetMin(int NumerOne, int NumberTwo)
        {
            double result = (NumerOne < NumberTwo) ? (NumerOne) : (NumberTwo);
            return result;
        }
        static double GetGipotinuza(double NumerOne, double NumberTwo)
        {
            double result = Math.Sqrt(Math.Pow(NumerOne, 2) + Math.Pow(NumberTwo, 2));
            return result;
        }

        static double NOD(double NumerOne, double NumberTwo)
        {
            while (NumerOne != NumberTwo)
            {
                if (NumerOne > NumberTwo) NumerOne -= NumberTwo;
                else NumberTwo -= NumerOne;
            }
            return NumerOne;
        }

        static bool IsEven(uint NumerOne)
        {
            return (NumerOne % 2 == 0) ? (true) : (false);
        }

        static byte GetQuantityOfEven()
        {
            byte quantity = 0;

            for (int i = 1; i <= 8; i++)
            {
                uint nunber = Convert.ToUInt32(Console.ReadLine());
                if (IsEven(nunber)) quantity++;
            }
            return quantity;
        }

        static uint GetSumOfDigits(uint NumerOne)
        {
            uint S = 0;
            while (NumerOne > 0)
            {
                S += NumerOne % 10;
                NumerOne /= 10;
            }
            Console.WriteLine(S);

            return S;
        }

        static void GetDigits(ulong NumerOne)
        {
            byte a;

            while (NumerOne > 0)
            {
                a = (byte)(NumerOne % 10);
                Console.Write($"{a} ");
                NumerOne /= 10;
            }
        }

        static uint Fibbonachi(uint a0, uint a1, uint k)
        {
            uint nextElement = a0;
            for (uint i = 2; i <= k; i++)
            {
                nextElement += a0 + a1;

                a0 = a1;
                a1 = nextElement;
            }
            if (k == 1) return a0;
            if (k == 2) return a1;
            return nextElement;
        }

        static double Distance(double x1, double y1, double x2, double y2)
        {
            double result = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            return result;
        }

        static double Perimetr(double NumerOne, double NumberTwo, double NumerTree)
        {
            double result = NumerOne + NumberTwo + NumerTree;
            return result;
        }

        static uint GetSumNotIven(uint NumerOne)
        {
            uint S = 0;
            while (NumerOne > 0)
            {
                uint a = NumerOne % 10;
                if (a % 2 != 0)
                {
                    S += a;
                }
                NumerOne /= 10;
            }
            return S;
        }

        static uint NextGetSumNotIven(uint NumerOne, uint NumberTwo)
        {
            uint result = NumerOne + 1;
            while (GetSumNotIven(result) != NumberTwo)
            {
                result++;
            }
            return result;
        }

        static int SumDelit(int NumerOne)
        {
            int S = 0;
            int delit = 2;
            while (NumerOne > 1)
            {
                if (NumerOne % delit == 0)
                {
                    S += delit;
                    NumerOne /= delit;
                }
                else
                {
                    delit++;
                }
            }
            return S;
        }

        static void Main(string[] args)
        {
            /*Задание 1. Вычислить значение выражения, определив необходимый метод. */
            /*//a
            Console.WriteLine($"a)\nx={GetSqrtSum(6) / 2 + GetSqrtSum(13) / 2 + GetSqrtSum(21) / 2}");
            Console.WriteLine($"y={GetSumSin(1) / 3 + GetSumSin(5) / 3 + GetSumSin(3) / 3}");

            //b
            Console.WriteLine($"b)\nx={GetSumSqrt(5) / GetSqrtSum(7) + GetSumSqrt(12) / GetSqrtSum(8) + GetSumSqrt(31) / GetSqrtSum(2)}");
            Console.WriteLine($"y={GetSumSin(2) / GetSinSum(5) + GetSumSin(6) / GetSinSum(3) + GetSumSin(1) / GetSinSum(4)}");

            //c
            Console.WriteLine($"c)\nx={GetXSumSqrtYDevideYSumSqrtX(15, 8) + GetXSumSqrtYDevideYSumSqrtX(6, 12) + GetXSumSqrtYDevideYSumSqrtX(7, 21)}");
            Console.WriteLine($"y={GetXSumSinYDevideYSumSinX(1,4) + GetXSumSinYDevideYSumSinX(3,2) + GetXSumSinYDevideYSumSinX(7,5)}");

            //d
            Console.WriteLine($"d)\nx={GetXSumSqrtYDevideYSumSqrtX(13, 7) + GetXSumSqrtYDevideYSumSqrtX(15, 12) + GetXSumSqrtYDevideYSumSqrtX(32, 21)}");
            Console.WriteLine($"y={GetXSumSinYDevideYSumSinX(2,3) + GetXSumSinYDevideYSumSinX(1,5) + GetXSumSinYDevideYSumSinX(4,7)}");*/


            /*Задание 2. Определить методы для вычисления максимального и
             * минимального из двух чисел. Вычислить значение выражений:
            a. max (a, 2b) ∙ min (2a − b, b)
            b. min(a, 3b) + max(2a − b, 2b)*/

            /*Console.WriteLine("Введите a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"a)\n{GetMax(a, 2 * b) * GetMin(2 * a - b, b)}");
            Console.WriteLine($"b)\n{GetMin(a, 3 * b) + GetMax(2 * a - b, 2 * b)}");*/


            /*Задание 3. Определить функцию для расчета гипотенузы
             * прямоугольного треугольника по его катетам. Найти периметр фигуры
            ABCD по заданным сторонам AB, AC и DC.*/

            /*Console.WriteLine("Введите AB");
            double AB = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите AC");
            double AC = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите DC");
            double DC = Convert.ToInt32(Console.ReadLine());

            double BC = GetGipotinuza(AB, AC);//5
            Console.WriteLine($"BC={BC}");
            Console.WriteLine($"Pabcd={GetGipotinuza(BC, DC) + AB + AC + DC}");*/


            /*Задание 4. Даны два натуральных числа. Определить, используя методы:
            a. в каком из чисел сумма цифр наибольшая
            b. в каком числе больше цифр
            c. являются ли числа палиндромами («перевернышами»)
            d. наименьшее общее кратное чисел*/

            /*Console.WriteLine("Введите a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b");
            int b = Convert.ToInt32(Console.ReadLine());*/


            /*Задание 5. Найти наибольший общий делитель трех натуральных
             * чисел, имея в виду, что НОД(a, b, c) = НОД(НОД(a, b), c). 
             * Определить функцию для расчета наибольшего общего делителя двух натуральных
            чисел.*/

            /*Console.WriteLine("Введите a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(NOD(a,b));*/


            /*Задание 6. Даны натуральные числа a и b, обозначающие
             * соответственно числитель и знаменатель дроби. Сократить дробь, т. е.
            найти такие натуральные числа p и q, не имеющие общих делителей, что*/

            /*Console.WriteLine("Введите a");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b");
            int b = Convert.ToInt32(Console.ReadLine());

            double p = a / NOD(a, b);
            double q = b / NOD(a, b);

            Console.WriteLine($"p/q = {p}/{q}");*/


            /*Задание 7. Даны две последовательности целых чисел: 𝑎𝑎1, 𝑎𝑎2, … , 𝑎𝑎8 и
             * 𝑏𝑏1, 𝑏𝑏2, … , 𝑏𝑏8. Найти количество четных чисел в первой из них и
            количество нечетных во второй. Определить методы, позволяющую
            распознавать четные числа.)*/

            /*for (int i = 0; i <= 2; i++)
            {
                Console.WriteLine("Введите 8 натуральных чисел:");
                Console.WriteLine($"Количество четных чисел: {GetQuantityOfEven()}");
            }*/


            /*Задание 11. Написать рекурсивный метод:*/

            //b
            //Console.WriteLine(GetSumOfDigits(1234));
            //d
            //GetDigits(1234);

            /*Задание 15. Написать рекурсивную функцию для вычисления k-го члена
             * последовательности Фибоначчи*/

            /*Console.Write("Введите k: ");
            uint k = Convert.ToUInt32(Console.ReadLine());

            uint a0 = 0;
            uint a1 = 1;

            Console.WriteLine(Fibbonachi(a0, a1, k));*/


            //Задание из 9 практики
            /*Console.Write(Numbers.GetSumOfDigits(228));*/


            //Вариант 20
            /*№1. Разработать метод 𝑓𝑓(x1, у1, х2, у2), который вычисляет длину
             * отрезка но координатам вершин (x1, у1) и (x2, у2), и метод 𝑑𝑑(𝑎𝑎, 𝑏𝑏, 𝑐𝑐),
            который вычисляет периметр треугольника по длинам сторон 𝑎𝑎, 𝑏𝑏, 𝑐𝑐. С
            помощью данных методов найти периметр треугольника, заданного
            координатами своих вершин.*/

            /*Console.WriteLine("Введите x11");
            double x11 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y11");
            double y11 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите x21");
            double x21 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y21");
            double y21 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите x12");
            double x12 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y12");
            double y12 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите x22");
            double x22 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y22");
            double y22 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите x13");
            double x13 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y13");
            double y13 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите x23");
            double x23 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите y23");
            double y23 = Convert.ToInt32(Console.ReadLine());

            double a = Distance(x11, y11, x21, y21);
            double b = Distance(x12, y12, x22, y22);
            double c = Distance(x13, y13, x23, y23);

            Console.WriteLine(Perimetr(a,b,c));*/


            /*№2. Разработать метод, который для заданного натурального числа N
             * возвращает сумму его нечетных цифр. С помощью данного метода для
            заданного числа А вывести на экран ближайшее следующее по
            отношению к нему число, сумма нечетных цифр которого равна сумме
            нечетных цифр числа А.*/

            /*Console.WriteLine("Введите N ");
            uint N = Convert.ToUInt32(Console.ReadLine());

            Console.WriteLine(GetSumNotIven(N));

            Console.WriteLine("Введите A ");
            uint A = Convert.ToUInt32(Console.ReadLine());

            Console.WriteLine(NextGetSumNotIven(A, GetSumNotIven(N)));*/


            /*№3. Разработать метод, который для заданного натурального числа
             * находит сумму простых множителей. С помощью данного метода для
            каждого целого числа на отрезке [𝑎𝑎, 𝑏𝑏] вывести на экран сумму его
            простых множителей.*/

            Console.WriteLine("Введите a ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b ");
            int b = Convert.ToInt32(Console.ReadLine());

            for (int i = a; i < b; i++)
            {
                Console.WriteLine(SumDelit(i));
            }





            Console.ReadKey();
        }
    }
}
