﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Library11
{
    public class Lib11
    {
        public static int CountWords(string sentence)
        {
            if (string.IsNullOrEmpty(sentence))
            {
                return 0;
            }

            string[] words = sentence.Split(' ');
            return words.Length;
        }

        public static bool JiSi(string sentence)
        {
            if (sentence.Contains("жы") || sentence.Contains("шы"))
            {
                return false;
            }

            if (sentence.Contains("жи") || sentence.Contains("ши"))
            {
                return true;
            }

            return true;
        }



        public static int SumFirstCahrsWord(string sentence, char letter)
        {
            if (string.IsNullOrEmpty(sentence))
            {
                return 0;
            }

            char lowerLetter = char.ToLower(letter);

            string[] words = sentence.Split(' ');

            int count = 0;

            foreach (string word in words)
            {
                if (!string.IsNullOrEmpty(word) && word.Length > 0 && char.ToLower(word[0]) == lowerLetter)
                {
                    count++;
                }
            }

            return count;
        }

        // Прямой поиск палиндрома
        public static void Print(string[] array)
        {
            uint i = 1;
            foreach (string a in array)
            {
                Console.WriteLine($"{i}. {a}");
                i++;
            }
        }

        public static void GetCategoryUnicode(char symbol)
        {
            Console.Write($"Unicode-символ \"{symbol}\" это ");

            if (char.IsLetter(symbol))
                Console.WriteLine("Буква ");

            if (char.IsUpper(symbol))
            {
                Console.Write("Верхний регистр ");
                char lowerCase = char.ToLower(symbol);
                Console.WriteLine($"\nБуква в нижнем регистре: {lowerCase}");
            }

            if (char.IsLower(symbol))
            {
                Console.Write("Нижний регистр");
                char upperCase = char.ToUpper(symbol);
                Console.WriteLine($"\nБуква в нижнем регистре: {upperCase}");
            }

            if (char.IsControl(symbol))
                Console.WriteLine("Управляющий символ ");

            if (char.IsNumber(symbol))
            {
                Console.WriteLine("Число ");
                int number = (int)char.GetNumericValue(symbol);
                Console.WriteLine($"Измененное число = {number + 1} ");
            }

            if (char.IsPunctuation(symbol))
                Console.WriteLine("Знак препинания");

            /* if (char.IsDigit(symbol))
                 Console.WriteLine("Цифра ");
            */

            if (char.IsSeparator(symbol))
                Console.WriteLine("Разделитель ");

            if (char.IsWhiteSpace(symbol))
                Console.WriteLine("Пробельный символ");

            Console.WriteLine();
        }

        // Метод для получения символа по указанной позиции
        public static char GetCharacterAtPosition(string word, int position)
        {
            return word[position];
        }

        // Метод для подсчёта вхождений символа
        public static int CountOccurrences(string word, char symbol)
        {
            int count = 0;

            foreach (char c in word)
            {
                if (c == symbol)
                {
                    count++;
                }
            }

            return count;
        }

        // Метод для замены выбранной буквы на другую выбранную в строке
        public static string LetterReplacement(string word, char let1, char let2)
        {
            return word.Replace(let1, let2);
        }

        // Метод для удаления из строки некоторого символа
        public static string LetterDelete(string word, char letter)
        {
            return word.Replace(letter.ToString(), string.Empty);
        }

        // Метод для вывода в столбик всех слов до запятой
        public static void WordsInAColumnBeforeComma(string sentence)
        {
            int comma = sentence.IndexOf(',');

            string partBeforeComma = comma != -1 ? sentence.Substring(0, comma) : sentence;

            string[] words = partBeforeComma.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string word in words)
            {
                Console.WriteLine(word);
            }
        }

        // Метод для замены пробелов на "_"
        public static string ReplaceWhiteSpaceToUnderscore(string sentence)
        {
            return sentence.Replace(" ", "_");
        }

        // Метод для проверки, является ли строка датой в формате "dd.mm.yyyy"
        public static void CheckingForDate(string sentence)
        {
            string pattern = @"\b(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.(19|20)\d{2}\b";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine("Обнаружены следующие даты в формате \"dd.mm.yyyy\":");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine("Формат даты \"dd.mm.yyyy\" не обнаружен.");
            }
        }

        // Метод для поиска всех email адресов в тексте
        public static void CheckingForEmail(string sentence)
        {
            string pattern = @"[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine("Обнаружены следующие email-адреса:");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine("Email-адреса не обнаружены.");
            }
        }

        // Метод для проверки состоит ли строка только из буквенных символов
        public static void CheckingForLetters(string sentence)
        {
            string pattern = @"^[a-zA-Zа-яА-ЯёЁ\s]+$";
            Match regex = Regex.Match(sentence, pattern);
            if (regex.Success)
            {
                Console.WriteLine("Строка состоит только из буквенных символов.");
            }
            else
            {
                Console.WriteLine("Строка состоит не только из буквенных символов.");
            }
        }

        // Метод для поиска всех слов, начинающихся с определенной буквы
        public static void SearchWordsStartedWithLetter(string sentence, char symbol)
        {
            char changedSymbol;
            if (char.IsUpper(symbol))
            {
                changedSymbol = char.ToLower(symbol);
            }
            else
            {
                changedSymbol = char.ToUpper(symbol);
            }
            string pattern = $@"\b{symbol}|{changedSymbol}\w*\b";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine($"Обнаружены следующие слова, начинающиеся на \"{symbol}\":");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine($"Слова на \"{symbol}\" не обнаружены.");
            }
        }

        // Метод для поиска всех цифровых значений в строке, разделенных запятой
        public static void SearchNumericSeparatedComma(string sentence)
        {
            string pattern = @"\b\d+\,\s\d+\b";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine($"Цифровые значения, разделённые запятой:");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine($"Цифровые значения, разделённые запятой, не найдены");
            }
        }

        // Метод для извлечения из строки всех чисел
        public static void AllNumbersFromString(string sentence)
        {
            string pattern = @"\b\d+(\.\d+)?\b";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine($"Все числа из строки:");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine($"Числа в строке не были обнаружены.");
            }
        }

        // Метод для замены всех слов, начинающихся с заглавной буквы, словом, где первая буква будет строчной
        public static string ChangeFirstCapitalToSmall(string sentence)
        {
            string pattern = @"\b[A-ZА-Я]\w+\b";

            string result = Regex.Replace(sentence, pattern, match =>
            {
                return char.ToLower(match.Value[0]) + match.Value.Substring(1);
            });

            return result;
        }

        // Метод для удаления THML-тегов из строки
        public static string RemoveHTMLFromString(string sentence)
        {
            string pattern = @"<[^>]+>";

            return Regex.Replace(sentence, pattern, string.Empty);
        }
    }

    public class IndividualTasks
    {
        // Метод для определения, упорядочены ли по алфавиту символы строки
        public static bool IsAlphabetlyOrdered(string sentence)
        {
            char[] characters = sentence.ToCharArray();
            char[] sortedCharacters = (char[])characters.Clone();
            Array.Sort(sortedCharacters);

            return string.Compare(new string(characters), new string(sortedCharacters), StringComparison.Ordinal) == 0;
        }

        // Метод для определения, чётная ли строка
        public static bool EvenString(string sentence)
        {
            if (sentence.Length % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Метод для удаления центра строки (2 если чётная; 1 если не чётная)
        public static StringBuilder RemoveMiddleCharacters(string sentence)
        {
            StringBuilder result = new StringBuilder(sentence);
            if (sentence.Length > 2)
            {
                if (EvenString(sentence) == true)
                {
                    int middleIndex = (sentence.Length / 2) - 1;
                    result.Remove(middleIndex, 2);
                }
                else
                {
                    int middleIndex = sentence.Length / 2;
                    result.Remove(middleIndex, 1);
                }
                return result;
            }
            else return result;
        }

        // Метод для удаления из сообщения всех однобуквенных слов (вместе с пробелами)
        public static string RemoveSingleLetterWords(string sentence)
        {
            string pattern = @"\b\w\b\s*";

            string result = Regex.Replace(sentence, pattern, "", RegexOptions.IgnoreCase);

            result = Regex.Replace(result, @"\s+", " ").Trim();

            return result;
        }

        // Метод для нахождения дат, заданных в формате: "00.00.00"
        public static void CheckingForDate(string sentence)
        {
            string pattern = @"\b(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.\d{2}\b";
            MatchCollection matches = Regex.Matches(sentence, pattern);

            if (matches.Count > 0)
            {
                Console.WriteLine("Обнаружены следующие даты в формате \"00.00.00\":");
                foreach (Match match in matches)
                {
                    Console.WriteLine(match.Value);
                }
            }
            else
            {
                Console.WriteLine("Формат даты \"00.00.00\" не обнаружен.");
            }
        }

        public static long MultiplyNum(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return 0;
            }

            string[] parts = input.Split('_');
            long product = 1;
            bool hasNumbers = false;

            foreach (string part in parts)
            {
                if (int.TryParse(part, out int number))
                {
                    product *= number;
                    hasNumbers = true;
                }
            }

            if (hasNumbers)
            {
                return product;
            }
            else
            {
                return 0;
            }
        }


        public static string Ellipsis(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input;
            }

            StringBuilder sb = new StringBuilder(input);
            int i = 0;

            while (i < sb.Length)
            {
                if (sb[i] == '.')
                {
                    int start = i;
                    while (i < sb.Length && sb[i] == '.')
                    {
                        i++;
                    }
                    if (i - start > 1)
                    {
                        sb.Remove(start, i - start);
                        sb.Insert(start, "...");
                        i = start + 3;
                    }
                }
                else
                {
                    i++;
                }
            }

            return sb.ToString();
        }
    }
}
