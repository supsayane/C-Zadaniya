﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Library11;

namespace Praktik11
{
    internal class Program
    {


        static void Main(string[] args)
        {
            /*Задание 1. Пользователь задает некоторый символ. Для заданного
             * символа определить категорию Unicode-символа. Если пользователь
            ввел букву, определить регистр и вывести символ в противоположном
            регистре. Если пользователь ввел цифру, увеличить ее на 1. В остальных
            случаях вывести категорию символа.*/


            /*char a = Convert.ToChar(Console.ReadLine());

            if (char.IsLower(a) == true)
            {
                Console.WriteLine(char.ToUpper(a));
                Console.WriteLine(char.GetUnicodeCategory(a));
            }
            else if (char.IsUpper(a) == true)
            {
                Console.WriteLine(char.ToLower(a));
                Console.WriteLine(char.GetUnicodeCategory(a));
            }
            else if (char.IsDigit(a) == true)
            {
                Console.WriteLine(a + 1);
                Console.WriteLine(char.GetUnicodeCategory(a));
            }
            else
            {
                Console.WriteLine(char.GetUnicodeCategory(a));
            }*/


            /*Задание 2. Пользователь вводить слово, содержащее от 2 до 20
             * символов. Написать метод:*/

            /*string a = Convert.ToString(Console.ReadLine());
            if (a.Length >= 2 && a.Length <= 20)
            {
                //b/позволяющий определить одинаковы ли второй и четвертый
                //символы в нем;
                int num1 = Convert.ToInt32(Console.ReadLine());
                int num2 = Convert.ToInt32(Console.ReadLine());
                if (a[num1] == a[num2])
                {
                    Console.WriteLine("оиднаковы");
                }
                else
                {
                    Console.WriteLine("не оиднаковы");
                }

                //c/позволяющий получить его часть, образованную второй,
                //третьей и четвертой буквами;
                Console.WriteLine($"{ a[1]}{ a[2]}{ a[3]}");

                //a/ для вывода символа с заданной позицией;
                int num = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(a[num - 1]);

                //g/подсчитать количество вхождений некоторого символа,
                //заданного пользователем;

                char word = Convert.ToChar(Console.ReadLine());
                int NumWord = 0;
                char[] chars = {word};
                int index = a.IndexOfAny(chars);
                while (index != -1)
                {
                    NumWord++;
                    index = a.IndexOfAny(chars, index + 1);
                }
                Console.WriteLine(NumWord);

                //h. удалить, некоторый символ, введенный пользователем;
                char word = Convert.ToChar(Console.ReadLine());
                char[] chars = { word };
                string result = a.Replace(word.ToString(), "");
                Console.WriteLine(a);


                char word = Convert.ToChar(Console.ReadLine());
                string ReplaceWord = a.Replace(word.ToString(), "");
                Console.WriteLine(ReplaceWord);
            }
            else
            {
                Console.WriteLine("символов больше или меньше");
            }*/


            /*Задание 5. Дано предложение. В нем слова разделены одним пробелом
             * (начальные и конечные пробелы и символ "-" в предложении
            отсутствуют). В предложении присутствуют запятые. Написать методы,
            позволяющие:*/

            /*string sentence = Convert.ToString(Console.ReadLine());

            //a
            int WordCount = Lib11.CountWords(sentence);
            Console.WriteLine(WordCount);

            //c
            bool TrueFalse = Lib11.JiSi(sentence);
            Console.WriteLine(TrueFalse);

            //e
            char word = Convert.ToChar(Console.ReadLine());
            int result = Lib11.SumFirstCahrsWord(sentence, word);
            Console.WriteLine(result);*/


            //Вариант 16

            /*№1.Задана некоторая строка(использовать класс String). Разработать
                метод, позволяющий подсчитать произведение всех содержащихся в ней
                чисел(в строке могут встречаться только целые числа, а в качестве
                разделителя используется нижнее подчеркивание).*/

            /*string stringnum1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine(Lib11.MultiplyNum(stringnum1));*/


            /*№2. Задана некоторая строка (использовать класс StringBuilder).
             * Разработать метод, который заменяет все группы стоящих рядом точек
            на многоточие.*/

            /*string stringnum2 = Convert.ToString(Console.ReadLine());
            Console.WriteLine(Lib11.Ellipsis(stringnum2));*/


            Console.ReadKey();
        }
    }
}
