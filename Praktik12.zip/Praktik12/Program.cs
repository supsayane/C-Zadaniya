﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Praktik12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Задание 1. Считать дату рождения пользователя.*/
            //1) рассчитать возраст пользователя на текущий момент времени (с
            //точностью до дней);

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2006, 01, 04);
            TimeSpan timeSpan = dateTime - dateMy;
           
            Console.WriteLine(timeSpan);*/


            //2) определить, сколько полных лет прошло с момента его дня рождения;

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2006, 01, 04);
            TimeSpan timeSpan = dateTime - dateMy;

            Console.WriteLine(timeSpan.Days / 365);*/


            //3) определить, сколько месяцев прошло с момента его дня рождения;

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2006, 01, 04);
            TimeSpan timeSpan = dateTime - dateMy;

            Console.WriteLine((timeSpan.Days / 365) * 12 + (dateTime.Month - dateMy.Month));*/


            //4) определить, сколько недель прошло с момента его дня рождения;

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2006, 01, 04);
            TimeSpan timeSpan = dateTime - dateMy;

            Console.WriteLine(timeSpan.Days / 7);*/


            //5) определить, сколько часов прошло с момента его дня рождения;

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2006, 01, 04);
            TimeSpan timeSpan = dateTime - dateMy;

            Console.WriteLine(timeSpan.Days * 24);*/


            //6) определить сколько дней, часов, минут осталось до дня рождения;

            /*DateTime dateTime = DateTime.Now;
            DateTime dateMy = new DateTime(2026, 01, 04);
            TimeSpan timeSpan = dateMy - dateTime;

            Console.WriteLine($"{timeSpan.Days} {timeSpan.Hours} {timeSpan.Minutes}");*/


            //7) показать текущую дату и время в формате «dd.MM.yyyy HH:mm:ss».
            /*DateTime dateTime = DateTime.Now;
            Console.WriteLine(dateTime.ToString("dd.MM.yyyy HH:mm:ss"));*/


            /*Задание 2. Разработайте программу, которая рассчитывает, сколько времени
             * осталось до конца семестра (дата окончания семестра задается
            пользователем). Программа должна выводить результат в днях, часах,
            минутах и секундах.*/

            /*DateTime dateTime = DateTime.Now;

            Console.WriteLine("введите дату");
            string dateSemestorUser = Console.ReadLine();

            DateTime dateSemestor = DateTime.Parse(dateSemestorUser);

            TimeSpan timeSpan = dateSemestor - dateTime;

            Console.WriteLine(timeSpan);*/


            /*Задание 1. Разработайте программу, которая помогает отслеживать
             * временные промежутки между различными событиями. 
             * Пользователь вводит начальное событие (дата и время) и конечное событие (дата и время).
             * Программа должна:*/

            /*Console.WriteLine("введите дату1");
            string timeUser1 = Console.ReadLine();

            TimeSpan Time1 = TimeSpan.Parse(timeUser1);


            Console.WriteLine("введите дату2");
            string timeUser2 = Console.ReadLine();

            TimeSpan Time2 = TimeSpan.Parse(timeUser2);

            //1) рассчитать промежуток времени между этими событиями с использованием структуры TimeSpan;

            //TimeSpan timeSpan = Time2 - Time1;
            //Console.WriteLine(timeSpan);

            ///2) проверить, больше или меньше этот временной интервал, чем другой
            //заранее определенный интервал(запросить у пользователя) и вывести
            //разницу между промежутками в днях, часах и минутах.

            int result = TimeSpan.Compare(Time1, Time2);

            if (result > 0)
            {
                Console.WriteLine("дата1 больше дата2");
                TimeSpan timeSpan = Time1 - Time2;
                Console.WriteLine(timeSpan);
            }
            else if  (result == 0)
            {
                Console.WriteLine("дата1 равна дата2");
                TimeSpan timeSpan = Time1 - Time2;
                Console.WriteLine(timeSpan);
            }
            else
            {
                Console.WriteLine("дата1 меньше дата2");
                TimeSpan timeSpan = Time2 - Time1;
                Console.WriteLine(timeSpan);
            }*/


            /*Задание 2. Создайте программу, которая помогает пользователю планировать
             * выполнение нескольких задач в течение дня. Программа должна принимать
            на вход список задач с указанием времени начала и длительности каждой
            задачи. Необходимо проверить, нет ли пересечений во времени между
            задачами, и предложить оптимизированное расписание, если такие
            пересечения существуют.*/


            /*DateTime dateTime = DateTime.Now;

            Console.WriteLine("введите дату начала");
            string dateStart = Console.ReadLine();
            DateTime dateNum1 = DateTime.Parse(dateStart);

            Console.WriteLine("введите дату конца");
            string dateFinish = Console.ReadLine();
            DateTime dateNum2 = DateTime.Parse(dateFinish);



            while (true)
            {
                int resultStart = DateTime.Compare(dateTime, dateNum1);
                if (resultStart == 0)
                {
                    Console.WriteLine("Начните задание");
                }

                int resultFinish = DateTime.Compare(dateTime, dateNum2);
                if (resultFinish == 0)
                {
                    Console.WriteLine("Закончите задание");
                }
            }*/


            //Вариант 16
            /*Задание 1.    
             * Написать программу, которая находит ближайший рабочий день к
             указанной дате(учитывая выходные и праздники).*/

            string dateWork = Console.ReadLine();
            DateTime DateWork = DateTime.Parse(dateWork);

            Console.WriteLine(DateWork.DayOfWeek);

            if (DateWork.DayOfWeek == DayOfWeek.Saturday)
            {
                Console.WriteLine("Послезавтра");
            }
            else if (DateWork.DayOfWeek == DayOfWeek.Sunday)
            {
                Console.WriteLine("Завтра");
            }
            else
            {
                Console.WriteLine("Сегодня");
            }


            /*Задание 2.
             * Создайте программу, которая принимает список задач с их
             * временем начала и длительностью. Разработайте метод, который
             * позволяет автоматически предлагать оптимальное время для новой
             * задачи на основе существующих.*/
            
            
            
            Console.ReadKey();
        }
    }
}
